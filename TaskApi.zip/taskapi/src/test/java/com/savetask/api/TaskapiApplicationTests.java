package com.savetask.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
