package com.savetask.api.domain.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SaveTaskRequest {

	private String channel;
	private String conversationId;
	private String country;

	@JsonProperty("json_data")
	private TaskData taskData;

	private SecurityInfo security;

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getConversationId() {
		return conversationId;
	}

	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public TaskData getTaskData() {
		return taskData;
	}

	public void setTaskData(TaskData taskData) {
		this.taskData = taskData;
	}

	public SecurityInfo getSecurity() {
		return security;
	}

	public void setSecurity(SecurityInfo security) {
		this.security = security;
	}
}
