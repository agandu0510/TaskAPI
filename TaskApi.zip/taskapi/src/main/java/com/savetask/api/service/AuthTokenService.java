package com.savetask.api.service;

import org.springframework.stereotype.Service;

import com.savetask.api.domain.model.SecurityInfo;
import com.savetask.api.exceptions.InvalidAuthTokenException;

@Service
public class AuthTokenService {
	
	public void validateToken(SecurityInfo security) throws Exception {
		
		if(security == null) {
			throw new IllegalArgumentException("Invalid Auth token");
		}
		
		if(!isValid(security.getAuthToken(),security.getClientIp())) {
			throw new InvalidAuthTokenException("Security token is invalid!");
		}
	}

	private boolean isValid(String authToken, String clientIp) {
		return true;
	}

}
