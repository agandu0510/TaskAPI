package com.savetask.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.savetask.api.domain.model.ResumeTaskRequest;
import com.savetask.api.domain.model.ResumeTaskResponse;
import com.savetask.api.domain.model.SaveTaskRequest;
import com.savetask.api.domain.model.SaveTaskResponse;
import com.savetask.api.service.TaskService;

@RestController
@RequestMapping("/")
public class TaskController {

	@Autowired
	private TaskService taskService;
	
	
	@PostMapping("/savetask")
	public ResponseEntity saveTask(@RequestBody SaveTaskRequest request) {
		try {
			 SaveTaskResponse saveTask = taskService.saveTask(request);
			 return ResponseEntity.ok(saveTask);
		} catch (Exception e) {
		}
		
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	}
	
	@PostMapping("/resumetask")
	public ResponseEntity retrieveTask(@RequestBody ResumeTaskRequest request) {
		
		try {
			 ResumeTaskResponse resumeTask = taskService.resumetask(request);
			 return ResponseEntity.ok(resumeTask);
		} catch (Exception e) {
		}
		
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
	}
}
